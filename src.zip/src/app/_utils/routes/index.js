const ROUTER_API = {
  // Auth
  register: "/auth/local/register",
  signIn: "/auth/local",
};
export default ROUTER_API;
