// nếu dùng các hook có từ use thì thêm "use client" ở trên đầu vd: useState, useEffect,vvv
export default function News() {
    return (
        <div>Trang tin tức</div>
    );
}