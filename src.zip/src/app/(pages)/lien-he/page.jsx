// nếu dùng các hook có từ use thì thêm "use client" ở trên đầu vd: useState, useEffect,vvv
export default function Contact() {
    return (
        <div>Trang liên hệ</div>
    );
}